from setuptools import setup

setup(
    name="PreEntrega2",
    version="0.1",
    description="Segunda preentrega de curso de python",
    author="Pablo A. Bobarini",
    packages=["program"]
)